package edu.uncc.inclass10;

import java.io.Serializable;

public class Post implements Serializable {
    public String name, post_id, created_by_uid, post, created_at;

    public Post() {
    }

    public String getCreated_by_name() {
        return name;
    }

    public String getPost_id() {
        return post_id;
    }

    public String getCreated_by_uid() {
        return created_by_uid;
    }

    public String getPost_text() {
        return post;
    }

    public String getCreated_at() {
        return created_at;
    }

    public void setName(String created_by_name) {
        this.name = created_by_name;
    }

    public void setPost_id(String post_id) {
        this.post_id = post_id;
    }

    public void setCreated_by_uid(String created_by_uid) {
        this.created_by_uid = created_by_uid;
    }

    public void setPost(String post_text) {
        this.post = post_text;
    }

    public void setTime(String created_at) {
        this.created_at = created_at;
    }

    @Override
    public String toString() {
        return "Post{" +
                "created_by_name='" + name + '\'' +
                ", post_id='" + post_id + '\'' +
                ", created_by_uid='" + created_by_uid + '\'' +
                ", post_text='" + post + '\'' +
                ", created_at='" + created_at + '\'' +
                '}';
    }
}
